#ifndef B3_VECTOR_FLOAT4_H
#define B3_VECTOR_FLOAT4_H

#include "Bullet3Common/b3Transform.h"

//#define cross3(a,b) (a.cross(b))
#define float4 b3Vector3
//#define make_float4(x,y,z,w) b3Vector4(x,y,z,w)

#endif  //B3_VECTOR_FLOAT4_H
